library(shiny)
library(readr)
library(DT)

options(shiny.maxRequestSize=30*1024^2)

shinyServer(function(input, output, session) {
  
  source("DataInput.R", local=TRUE)
  source("Design.R", local=TRUE)
  source("DataPlot.R", local=TRUE)
  
  output$pivotData <- rpivotTable::renderRpivotTable({ 
    if (!is_empty(input$selecteddata) && is.data.frame(r_data[[input$selecteddata]])) rpivotTable::rpivotTable(data = r_data[[input$selecteddata]])
  })
  
  source("LMM.R", local=TRUE)
  
  ######################### Down load report ######################### 
  
  output$downloadReport2 <- downloadHandler(
    filename = function() {
      paste('my-report2', sep = '.', switch(
        input$format2, PDF = 'pdf', HTML = 'html', Word = 'docx'
      ))
    },
    
    content = function(file) {
      src <- normalizePath('report.Rmd') 
      # temporarily switch to the temp dir, in case you do not have write
      # permission to the current working directory
      owd <- setwd(tempdir())
      on.exit(setwd(owd))
      file.copy(src, 'report.Rmd')
      
      library(rmarkdown)
      out <- render('report.Rmd', switch(
        input$format2,
        PDF = pdf_document(), HTML = html_document(), Word = word_document()
      ))
      file.rename(out, file)
    }
  ) # end of downloadHandler 
  
  ######################### Stop App ######################### 
  observeEvent(input$quitrun, {
    stopApp(returnValue = invisible())
  })
  
  session$allowReconnect(TRUE)
  
})
