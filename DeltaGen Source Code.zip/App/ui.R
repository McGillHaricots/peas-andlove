library(shiny)
library(shinythemes)

shinyUI(navbarPage(title="DeltaGen (v 0.05-HASH)", windowTitle = "DeltaGen", id = "nav_DeltaGen", # div(img(src="images/DeltaGenlogo1.png", style="float:left"))
                   theme = shinytheme("cerulean"), collapsible = TRUE,
                   
                   # tags$head(
                   # tags$style(HTML("
                   # .sidebar { height: 90vh; overflow-y: auto; }
                   # " )
                   # )
                   # ),
                   
                   tabPanel("Introduction",
                            includeCSS(file.path("./www/style.css")),
                            fluidRow(
                              column(3,""),
                              column(6,
                                     br(),
                                     h4(shiny::p(
                                       "DeltaGen is a quantitative genetic analysis tool for plant breeders, developed by Dr. Zulfi Jahufer and Dr. Dongwen Luo.", 
                                       style="text-align:justify;color:black;background-color:lavender;padding:15px;border-radius:10px")),
                                     br(),
                                     img(src="images/DeltaGen.png"),
                                     br(),
                                     br(),
                                     h5(shiny::p(
                                       "The development of this program was funded by Pastoral Genomics, a joint venture co-funded by DairyNZ, Beef+Lamb New Zealand, Dairy 
									   Australia, AgResearch Ltd, New Zealand Agriseeds Ltd, Grasslands Innovation Ltd, DEEResearch, and the Ministry of Business, 
									   Innovation and Employment (New Zealand).", 
                                       style="text-align:justify;color:black;background-color:lavender;padding:15px;border-radius:10px")),
                              )
                            )
                   ),
                   
                   tabPanel("Trial Design",
                            
                            sidebarPanel(
                              selectInput("designtype", h4("Design Type"), c("Completely Randomized", "Randomized Complete Block", "Factorial", "Row and Column", "p-rep Design")),# "Split Plot", , 
                              actionButton("reset_designinput", "Reset inputs", class = "btn-primary btn-xs"),
                              uiOutput("designinput_ui"),
                              numericInput("seed", "Random seed", min=0, max=100000, step=1, value=0),
                              br(),
                              actionButton("designrun", "Run", class = "btn-success"),
                              checkboxInput("hidetab", "Hide tabulation", value = FALSE),
                              checkboxInput("hideanova", "Hide ANOVA", value = FALSE),
                              wellPanel(
							    h4("Save design data"),
                                textInput("designresultname",  "Design name:", value = ""),                                 								
                                radioButtons('designresultformat', 'Save format', c('csv', 'RData'), inline = TRUE), 
                                br(),								
                                div(class="row",
                                  div(class="col-xs-6",
                                    downloadButton('savedesignresult', 'Save result', class = "btn-info btn-xs")),
                                  div(class="col-xs-6",
                                    conditionalPanel("(input.designtype=='Row and Column' | input.designtype=='p-rep Design') & input.designresultformat!='RData'",								
                                  downloadButton('savedesignLayout', 'Save layout', class = "btn-info btn-xs")))
							  )), 
							  wellPanel(
                              h4("Download design report"),
                              radioButtons('format', 'Document format', c('Word', 'HTML'), inline = TRUE),  
                         	  br(),					  
                              downloadButton('downloadReport', class = "btn-info btn-xs")),
                              br(),
                              h4("Reference:"),
                              tags$p("Coombes, N.E. (2002) The Reactive Tabu Search for Efficient Correlated Experimental Designs. PhD Thesis, Liverpool John Moores University.")
                            ),# end of sidebarPanel
                            
                            mainPanel(
                              tabsetPanel(
                                tabPanel("Design Result",
                                         h4("Data Information"),
                                         verbatimTextOutput("designoutinfo"),
                                         h4("Data View"),
                                         dataTableOutput(outputId="designoutdf"),
                                         br(),
                                         # conditionalPanel(condition = "input.designtype == 'Row and Column'",
                                         # checkboxInput("sendDesignOpt", "Serpentine", value = TRUE, width = NULL),
                                         # selectInput("designstart", h4("Start corner"), c("Top left"="TL", "Top right"="TR", "Bottom left"="BL", "Bottom right"="BR")),
                                         # selectInput("designdirct", h4("Direction"), c("Horizontal"="H", "Virtical"="V")),
                                         # selectizeInput('traitsName', 'Names od traits:', c("Yield", "Growth", "Plant_Hight"),  multiple = TRUE,
                                         # options = list(create = TRUE, plugins = list('remove_button', 'drag_drop'))),
                                         # actionButton("sendDesign", "Send to input")
                                         # ),
                                         uiOutput("sendInput_ui")
                                         
                                ),
                                tabPanel("Design Check",
                                         h4("Tabulation"),
                                         verbatimTextOutput("designchktab"),
                                         h4("ANOVA"),
                                         verbatimTextOutput("designchkanova"),
                                         h4("Design Layout"),
                                         plotOutput("layoutplot")
                                )
                              )
                              
                              
                            ) # end of main panel
                            
                   ),                   
                   
                   tabPanel("Data Input", value="abcde",
                            sidebarPanel(
                              selectInput("selecteddata", label = "Datasets:", choices=NULL),
                              
                              wellPanel(condition="input.nav_PBT=='Upload' & input.DUpanel == 'Data'",
                                        radioButtons("dataiptype", NULL, c("Upload"="upload", "Examples"="examples", "Clipboard"="clipboard"), inline=TRUE ),
                                        br(),
                                        uiOutput("dataip_ui"),
                                        radioButtons("datainfo", h4("Show data:"), c("structure", "summary"), inline=TRUE),
                                        uiOutput("datarenames_ui"),
                                        uiOutput("datatypeChange_ui")
                              ),
                              wellPanel(
                                textInput("updtdataname",  "Data name:", value = "RenamedData"),
                                radioButtons('updtdataformat', 'Save format', c('RData', 'csv'), inline = TRUE),
                                br(),
                                downloadButton('saveupdtdata', 'Save Updated Data', class = "btn-info btn-xs"))
                            ),  # end of sidebarPanel
                            
                            mainPanel(
                              h4("Data Information"),
                              verbatimTextOutput("datastr1"),
                              
                              tabsetPanel(type="pills", 
                                          tabPanel("Data View", value = 10110,
                                                   br(),
                                                   DT::dataTableOutput(outputId="view1"),
                                                   br(),
                                                   actionButton("editData", "Edit data", class = "btn-primary btn-sm")),
                                          
                                          tabPanel("Data Input", value = 10111,
                                                   br(),
                                                   rHandsontableOutput("hotInputView"),
                                                   br(),
                                                   actionButton("updateBtn", "Update", class = "btn-primary btn-sm")),
                                          id = "DataView_Input")
                              
                            ) # end of main panel
                   ),
                   
                   navbarMenu("Graphs and Tables",
                              tabPanel("Plot",
                                       sidebarPanel(
                                         # selectInput("selectplotdata", label = "Datasets:", choices = NULL),
                                         actionButton("reset_plotinput", "Reset inputs", class = "btn-primary btn-xs"),
                                         uiOutput("ui_Visualize")
                                       ),
                                       mainPanel(
                                         # plot_downloader(".visualize", width = viz_plot_width(), height = viz_plot_height(), pre = ""), 
                                         plotOutput("visualize", width = "100%", height = "100%"),
                                         uiOutput("ui_savePlot")
                                       )
                              ),
                              tabPanel("Pivot Table", rpivotTable::rpivotTableOutput("pivotData"),
							                          h5("Note: please refer to quick start manu for detail instructions."))
                   ),
                   
                   navbarMenu("Models",
                              tabPanel("Univariate",
                                       sidebarPanel(h4('Linear Mixed Effects Model'),										 
                                                    wellPanel("Breeding Methods",
                                                              radioButtons('bredingtype', NULL, c('half sib family'='hsf', 'full sib family'='fsf', 'self-pollination'='selfP'), inline=TRUE),
                                                              conditionalPanel("input.bredingtype=='selfP'",  
                                                                               checkboxInput("selfP_early", "early stage", value = FALSE),
                                                                               conditionalPanel("!input.selfP_early",  
                                                                                                selectizeInput('selfP_F', 'F generation of line derivation', c("F1 = S0", paste("F", 2:11, sep=""), "DH"))	
                                                                               )					 
                                                              )),
                                                    tabsetPanel(type="pills", id="abcd",
                                                                tabPanel("Model",
                                                                         uiOutput("model_ui"),
                                                                         bsModal("modalhelp", "Basic Theory", "modelhelpBut", size = "large", withMathJax(HTML(includeMarkdown(file.path("./www/help_files/Heritability.Rmd"))))),
                                                                         br(),
                                                                         actionButton("modelhelpBut", "Help", class = "btn-primary btn-sm")
                                                                         
                                                                ),
                                                                tabPanel("InfoLoad",
                                                                         conditionalPanel("!input.selfP_early",
                                                                         wellPanel(h5("Number of levels for:"),
                                                                                   div(class="row",
                                                                                       div(class="col-xs-6",
                                                                                           selectInput("YearninfoSim", label = "Year (n):", choices=1:10)),
                                                                                       div(class="col-xs-6",
                                                                                           selectInput("SeaninfoSim", label = "Season (n):", choices=1:12)),		  
                                                                                       div(class="col-xs-6",
                                                                                           selectInput("LocninfoSim", label = "Location (n):", choices=1:50)),
                                                                                       div(class="col-xs-6",
                                                                                           selectInput("RepninfoSim", label = "Rep (n):", choices=1:10)),
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("SampleninfoSim", label = "Sample (n):",  1, min=1)),
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("LineninfoSim", label = "Line (n):",  1, min=1))				  
                                                                                   )),
                                                                         wellPanel(h5("Variance component for:"),	  
                                                                                   div(class="row",
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLinfoSim", label = "Line", 0, min=0)),																	
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VEinfoSim", label = "Error", 0, min=0)),																	
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLYinfoSim", label = "Line:Year", 0, min=0)),
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLSinfoSim", label = "Line:Season", 0, min=0)),		  
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLLocinfoSim", label = "Line:Location", 0, min=0)),
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLRepinfoSim", label = "Line:Replicates", 0, min=0)),
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLSampleinfoSim", label = "Line:Sample", 0, min=0)),			  
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("VLYSinfoSim", label = "Line:Year:Season", 0, min=0))		  
                                                                                   ),
                                                                                   numericInput("VLYLinfoSim", label = "Line:Year:Location", 0, min=0),
                                                                                   numericInput("VLSLinfoSim", label = "Line:Season:Location", 0, min=0),
                                                                                   numericInput("LineMinfoSim", label = "The BLUP mean of Lines", 0),
                                                                                   numericInput("LineMvarinfoSim", label = "The average of squared standard errors of Line BLUPs", 0)
                                                                         )),
																		 conditionalPanel("input.selfP_early",
                                                                        wellPanel(h5("Number of levels for:"),
                                                                                   div(class="row",                                                                                      
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("SampleninfoSimSPE", label = "Samples per line:", 1, min=1)),
                                                                                       div(class="col-xs-6",
                                                                                           numericInput("LineninfoSimSPE", label = "Lines/Plots (p-rep):",  1, min=1))				  
                                                                                   )),
                                                                         wellPanel(h5("Variance component for:"),	 
                                                                                   numericInput("VLinfoSimSPE", label = "Line", 0, min=0),
                                                                                   numericInput("LineMinfoSimSPE", label = "The BLUP mean of Lines", 0),
                                                                                   numericInput("LineMvarinfoSimSPE", label = "The average of squared standard errors of Line BLUPs", 0)
                                                                         )																		 
																		 ),
                                                                         actionButton("runinfoSim", "Submit", class = "btn-success"),
                                                                         br() 
                                                                         
                                                                ),
                                                                tabPanel(HTML("R / &Delta;G"), value="R/delta_G",
                                                                         bsModal("simulartionhelp", "Basic Theory", "simuhelpBut", size = "large", withMathJax(HTML(includeMarkdown(file.path("./www/help_files/Simulation.Rmd"))))),
                                                                         uiOutput("lmmsim_ui")
                                                                )
                                                    )
                                       ),# end of sidebarPanel
                                       
                                       mainPanel(
                                         conditionalPanel(#"input.lmmMS=='lmmodel'",
                                           # condition="input.conditionedPanels == 'Model'",
                                           condition="input.abcd == 'Model'",
                                           tabsetPanel(
                                             tabPanel("Model Output",
                                                      conditionalPanel("!input.hideDataInfo2",
                                                                       h4("Data Information"),
                                                                       verbatimTextOutput("datastr3")),
                                                      tabsetPanel(type="pills",
                                                                  tabPanel("Modeling Results", value = 19,
                                                                           verbatimTextOutput("modsummary"),
                                                                           br()),
                                                                  tabPanel("BLUP", value = 110,
                                                                           verbatimTextOutput("modblup"),
                                                                           rHandsontableOutput("hot"),
                                                                           h5("Note: right click to download the table.")),                                                                                 
                                                                  tabPanel("BLUE", value = 111,
                                                                           verbatimTextOutput("modblue"),                                                                                          
                                                                           rHandsontableOutput("hotBlue"),
                                                                           h5("Note: right click to download the table.")),
                                                                  tabPanel("Pattern Analysis -- Cluster", value = 1112,
                                                                           h4("Cluster Groups"),
                                                                           verbatimTextOutput("patterngroup"),
                                                                           h4(""),
                                                                           plotOutput("patternheat")),
                                                                  tabPanel("Pattern Analysis -- PCA", value = 1113,
                                                                           verbatimTextOutput("patternPCA"),
                                                                           h4("Biplot of Pattern Analysis"),
                                                                           plotOutput("patternbiplot")),	
                                                                  id = "modeltabsetPanel")
                                             ),
                                             tabPanel("Residual Plots",plotOutput("residualplot")),
                                             id="LMMpanel")),
                                         conditionalPanel(condition="input.abcd == 'InfoLoad'",
                                                          br(),
                                                          h4("Formula:"),
                                                          uiOutput('formula_LMH'),
                                                          h4("Line Mean Heritability is:"),
                                                          verbatimTextOutput("infoSimout")),										 
                                         conditionalPanel(condition="input.abcd == 'R/delta_G'",
                                                          h4("Breeding Strategies and Simulation"),														  
                                                          DT::dataTableOutput(outputId="simtable1"),
                                                          uiOutput('undoUI'),
                                                          br(),
                                                          DT::dataTableOutput(outputId="simtable2"),
                                                          br(),
                                                          DT::dataTableOutput(outputId="simtable3")
                                         )
                                       )
                              ),
                              tabPanel("Multivariate",
                                       sidebarPanel(
                                         bsModal("SHindexhelp", "Basic Theory", "SHindexhelpBut", size = "large", withMathJax(HTML(includeMarkdown(file.path("./www/help_files/Smith-Hazel Index.Rmd"))))),
                                         uiOutput("multitraits_ui")
                                       ),# end of sidebarPanel
                                       
                                       mainPanel(
                                         conditionalPanel("input.multitype=='mplot'",
                                                          tabsetPanel(type="pills",
                                                                      tabPanel("Biplot", value = 113,
                                                                               plotOutput("pcabiplot")),
                                                                      tabPanel("Matrix Plot", value = 114,
                                                                               verbatimTextOutput("cormatrix"),																	  																	           
                                                                               plotOutput("matrixplot")),
                                                                      id = "mplottabsetPanel")),
                                         conditionalPanel("input.multitype=='manova'",
                                                          verbatimTextOutput("vcovdecompose")),
                                         conditionalPanel("input.multitype=='selectIndex'",
                                                          verbatimTextOutput("ISsummary"))
                                       )
                              )
                   ),
                   
                   tabPanel("Pattern Analysis",
                            sidebarPanel(
                              uiOutput("pattern_ui")
                            ),  # end of sidebarPanel
                            
                            mainPanel(
                              tabsetPanel(type="pills",
                                          tabPanel("Cluster Analysis", value = 1113,
                                                   div(class="row",
                                                       div(class="col-xs-4",
                                                           h4("Cluster groups"),
                                                           rHandsontableOutput("mpatterngroupTB"),
                                                           h5("Note: right click to download the table.")
                                                       ),
                                                       div(class="col-xs-8",
                                                           h4("Heatmap plot"),
                                                           plotOutput("mpatternheat")
                                                       )
                                                   )
                                          ),
                                          tabPanel("Cluster summary", value = 1115,
                                                   h4("Cluster summary:"),
                                                   verbatimTextOutput("mpatterngroupSumry"),
                                                   checkboxInput("plt_cluster_mean", "Plot cluster means?", FALSE),
                                                   conditionalPanel("input.plt_cluster_mean",
                                                                    textInput("cluster_meanM",  "Plot title:", value = "Performance plots: Cluster means"),
                                                                    textInput("cluster_meanX",  "x label:", value = "Location"),
                                                                    textInput("cluster_meanY",  "y label:", value = "Cluster Means"),
																	checkboxInput("cluster_meanEnI", "Plot environmental index?", TRUE),
                                                                    br(),
                                                                    actionButton("plt_cluster_meanRun", "Plot", class = "btn-success btn-xs")														  
                                                   ),
                                                   br(),
                                                   plotOutput("cluster_meanPlot")
                                          ),										  
                                          tabPanel("PCA Biplot", value = 1114,
                                                   verbatimTextOutput("mpatternPCA"),
                                                   h4("Biplot of Pattern Analysis"),
                                                   plotOutput("mpatternbiplot")),			   
                                          id = "patternAnalysisPanel")
                            ) # end of main panel
                   ),
                   
                   tabPanel("Save & Quit",
                            sidebarPanel(
                              h4("Download Reports"),
                              radioButtons('format2', 'Document format', c('Word', 'HTML'), inline = TRUE),
                              br(),
                              downloadButton('downloadReport2', class = "btn-info btn-sm"),
                              actionButton("quitrun", "Quit App", class = "btn-danger btn-sm")
                            ),  # end of sidebarPanel
                            
                            mainPanel(""
                            ) # end of main panel
                   ),
                   
                   navbarMenu("Help",
                              tabPanel("Quick start guide", br(),br(),
                                       tags$iframe(style="height:700px; width:100%; scrolling=yes",
                                                   src="help_files/QuickStartGuideDeltaGen.pdf")),
                              
                              tabPanel("About", 
                                       fluidRow(
                                         column(2,
                                                br(),
                                                img(src="images/Zulfi_Jahufer.jpg"), offset=1),
                                         column(4,
                                                br(),
                                                tags$h4("Dr Zulfi Jahufer"),
                                                tags$p("Senior Scientist: Quantitative Genetics & Plant Breeding:  AgResearch Ltd, Grasslands Research Centre, New Zealand."),
                                                tags$p("Adjunct Associate Professor in Plant Breeding: Massey University."),
                                                tags$p("Email: zulfi.jahufer@agresearch.co.nz")),
                                         column(2,
                                                br(),
                                                img(src="images/Dongwen_Luo.jpg"), offset=0.5),
                                         column(4,
                                                br(),
                                                tags$h4("Dr Dongwen Luo"),
                                                tags$p("Senior Statistician: Knowledge & Analytics:  AgResearch Ltd, Grasslands Research Centre, New Zealand."),
                                                tags$p("Email: dongwen.luo@agresearch.co.nz")
                                         )
                                       )    
                              )
                   ),
                   
                   tabPanel("Acknowledgements",
                            fluidRow(
                              br(),
                              column(3,""),
                              column(6,  style="text-align:justify;color:black;background-color:lavender;padding:15px;border-radius:10px",
                                     tags$h4("Dr. Luis Apiolaza, NZ School of Forestry, University of Canterbury"),
                                     tags$h4("Dr. Vivi Arief, The University of Queensland, Australia"),
                                     tags$h4("Mr. Brent Barrett, AgResearch Ltd NZ"), 	
                                     tags$h4("Dr. Michael Casler USDA - ARS, Madison, Wisconsin"), 
                                     tags$h4("Dr. Mingshu Cao, AgResearch Ltd NZ"),
                                     tags$h4("Dr. Tony Conner, AgResearch Ltd NZ"), 
                                     tags$h4("Dr. Neil Coombes, NSW DPI Australia"),
                                     tags$h4("Mr. Mario D’Antuono, DPIRD Western Australia"),
                                     tags$h4("Dr. Ken Dodds, AgResearch Ltd NZ"), 
                                     tags$h4("Dr. Marty Faville, AgResearch Ltd NZ"),
                                     tags$h4("Dr. Siva Ganesh, AgResearch Ltd NZ"), 
                                     tags$h4("Dr. Andrew Griffiths, AgResearch Ltd NZ"),                                      
                                     tags$h4("Dr. Jeanne Jacobs, AgResearch Ltd NZ"),
                                     tags$h4("Dr. Jingli Liu, AgResearch Ltd NZ"),
                                     tags$h4("Dr. Dan Sun, AgResearch Ltd NZ"))  # 
                            )
                   ),
                   
                   tabPanel(div(img(src="images/DeltaGenlogo1.png", style="float:left")),"")
))
