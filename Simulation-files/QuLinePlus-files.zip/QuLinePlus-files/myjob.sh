#!/bin/bash
#SBATCH --time=2-00:00:00
#SBATCH --account=def-haricots
#SBATCH --mem=91000M

chmod +x Qulineplus_gfortran_v00.00.10
./Qulineplus_gfortran_v00.00.10
